import java.util.*;

/** Mission 5. Dynamic programming on a tree rooted at person 0. */
public class Outbreak {
    /**
     * Minimum-cost vertex cover of the tree. If v is excluded, every child is
     * included; if v is included, each child takes its cheaper state.
     */
    public static boolean[] cheapestTests(int n, int[][] nb, int[] cost) {
        long[] take = new long[n];
        long[] skip = new long[n];
        int[] parent = new int[n];
        Arrays.fill(parent, -2);
        int[] order = new int[n];
        int size = 0;
        order[size++] = 0;
        parent[0] = -1;
        for (int i = 0; i < size; i++) {
            int v = order[i];
            for (int u : nb[v]) {
                if (u == parent[v]) continue;
                parent[u] = v;
                order[size++] = u;
            }
        }
        for (int i = size - 1; i >= 0; i--) {
            int v = order[i];
            take[v] = cost[v];
            skip[v] = 0;
            for (int u : nb[v]) {
                if (parent[u] == v) {
                    take[v] += Math.min(take[u], skip[u]);
                    skip[v] += take[u];
                }
            }
        }

        boolean[] tested = new boolean[n];
        ArrayDeque<Integer> stack = new ArrayDeque<>();
        boolean[] state = new boolean[n];
        state[0] = take[0] <= skip[0];
        stack.push(0);
        while (!stack.isEmpty()) {
            int v = stack.pop();
            tested[v] = state[v];
            for (int u : nb[v]) {
                if (parent[u] == v) {
                    state[u] = !state[v] || take[u] <= skip[u];
                    stack.push(u);
                }
            }
        }
        return tested;
    }

    /** Tree diameter in edges, found from the two longest downward branches at each vertex. */
    public static int longestChain(int n, int[][] nb) {
        int[] parent = new int[n];
        Arrays.fill(parent, -2);
        int[] order = new int[n];
        int size = 0;
        order[size++] = 0;
        parent[0] = -1;
        for (int i = 0; i < size; i++) {
            int v = order[i];
            for (int u : nb[v]) {
                if (u == parent[v]) continue;
                parent[u] = v;
                order[size++] = u;
            }
        }
        int[] down = new int[n];
        int best = 0;
        for (int i = size - 1; i >= 0; i--) {
            int v = order[i];
            int first = 0, second = 0;
            for (int u : nb[v]) {
                if (parent[u] == v) {
                    int length = down[u] + 1;
                    if (length > first) {
                        second = first;
                        first = length;
                    } else if (length > second) {
                        second = length;
                    }
                }
            }
            down[v] = first;
            best = Math.max(best, first + second);
        }
        return best;
    }
}
