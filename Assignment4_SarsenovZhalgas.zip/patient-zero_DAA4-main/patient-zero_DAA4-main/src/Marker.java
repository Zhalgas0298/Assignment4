import java.util.*;

/** Missions 3 and 4: prefix-function/KMP and Rabin-Karp rolling hash. */
public class Marker {
    /** pi[i] is the longest proper prefix of p[0..i] that is also its suffix. */
    public static int[] prefixFunction(String p) {
        int n = p.length();
        int[] pi = new int[n];
        for (int i = 1; i < n; i++) {
            int j = pi[i - 1];
            while (j > 0 && p.charAt(i) != p.charAt(j)) j = pi[j - 1];
            if (p.charAt(i) == p.charAt(j)) j++;
            pi[i] = j;
        }
        return pi;
    }

    /** KMP search. Returns all match starts, including overlapping occurrences. */
    public static int[] findAll(String text, String p) {
        if (p.isEmpty()) return new int[0];
        int[] pi = prefixFunction(p);
        ArrayList<Integer> hits = new ArrayList<>();
        int j = 0;
        for (int i = 0; i < text.length(); i++) {
            while (j > 0 && text.charAt(i) != p.charAt(j)) j = pi[j - 1];
            if (text.charAt(i) == p.charAt(j)) j++;
            if (j == p.length()) {
                hits.add(i - p.length() + 1);
                j = pi[j - 1];
            }
        }
        int[] result = new int[hits.size()];
        for (int i = 0; i < result.length; i++) result[i] = hits.get(i);
        return result;
    }

    /**
     * Rabin-Karp: hash every length-k window of b, then roll over windows of a.
     * A matching hash is verified character-by-character to reject collisions.
     */
    public static int sharedWords(String a, String b, int k) {
        if (k <= 0 || a.length() < k || b.length() < k) return 0;
        final long mod = 1_000_000_007L;
        final long base = 911_382_323L;
        long high = 1;
        for (int i = 1; i < k; i++) high = (high * base) % mod;

        Map<Long, ArrayList<Integer>> positionsInB = new HashMap<>();
        long hash = 0;
        for (int i = 0; i < k; i++) hash = (hash * base + value(b.charAt(i))) % mod;
        positionsInB.computeIfAbsent(hash, x -> new ArrayList<>()).add(0);
        for (int start = 1; start + k <= b.length(); start++) {
            long leading = (value(b.charAt(start - 1)) * high) % mod;
            hash = (hash - leading + mod) % mod;
            hash = (hash * base + value(b.charAt(start + k - 1))) % mod;
            positionsInB.computeIfAbsent(hash, x -> new ArrayList<>()).add(start);
        }

        int count = 0;
        hash = 0;
        for (int i = 0; i < k; i++) hash = (hash * base + value(a.charAt(i))) % mod;
        for (int start = 0; start + k <= a.length(); start++) {
            ArrayList<Integer> candidates = positionsInB.get(hash);
            boolean found = false;
            if (candidates != null) {
                for (int other : candidates) {
                    int j = 0;
                    while (j < k && a.charAt(start + j) == b.charAt(other + j)) j++;
                    if (j == k) { found = true; break; }
                }
            }
            if (found) count++;
            if (start + k < a.length()) {
                long leading = (value(a.charAt(start)) * high) % mod;
                hash = (hash - leading + mod) % mod;
                hash = (hash * base + value(a.charAt(start + k))) % mod;
            }
        }
        return count;
    }

    private static int value(char c) {
        return switch (c) {
            case 'A' -> 1;
            case 'C' -> 2;
            case 'G' -> 3;
            case 'T' -> 4;
            default -> c + 1;
        };
    }
}
