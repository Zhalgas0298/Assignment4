# Assignment 4. Patient Zero

**Student ID:** 254018
**Name:** Sarsenov Zhalgas

**Group:** SE-2519

## Program output

Generated with `java tools/MakeVariant.java 254824 data` and calculated by the Java program:

```text
Mutations: 107
Shared core: 1069
Marker hits: 5
First hit: 12347
Border length: 4
Shared words: 324
Tests needed: 33
Cheapest testing: 157
Longest chain: 33
```

My outbreak report: `output/outbreak.html` (open it in a browser). The screenshot is `output/outbreak.png` when generated locally.

## Questions

**Mission 1. What does d[i][j] mean, and how is it computed?**
`d[i][j]` is the minimum number of single-character edits needed to change the first `i` characters of A into the first `j` characters of B. It is the minimum of deleting a character, inserting a character, or matching/replacing the last characters; the first row and column are initialized to the lengths of the prefixes.

**Mission 2. How is LCS different from the longest common substring? Why can Shared core exceed same-position matches?**
A subsequence keeps the order of characters but may skip characters, while a substring must be consecutive. Therefore, letters can contribute to the LCS even when insertions or deletions have shifted their positions in the two strains.

**Mission 3. What does the prefix function tell you, and why does the text pointer never go back in KMP? What is this marker's Border length?**
The prefix function gives, for each prefix of the marker, the length of its longest proper prefix that is also a suffix. KMP uses this information to continue from the longest still-possible prefix after a mismatch, so the text index only moves forward. For my marker, the Border length is **4**, meaning its longest proper prefix that is also a suffix has four characters.

**Mission 4. Why compare letters after hashes match? What if many windows have the same hash?**
Different strings can have the same hash because the hash maps many possible strings to a smaller set of numbers. Comparing the actual characters prevents a collision from being counted as a match; if many windows share a hash, the verification work increases and the worst-case time can approach O(nk).

**Mission 5. What are the two tree-DP states, and why can greedy fail?**
For each person, one state is the minimum cost when that person is tested, and the other is the minimum cost when that person is not tested. If a person is not tested, every child must be tested; if the person is tested, each child can use its cheaper state. A greedy choice based only on the number of links can miss the globally cheapest combination because testing costs and neighbouring choices both matter.

## AI use

ChatGPT was used to explain the assignment and algorithms

## Timing (Mission 7)

Measurements below are from `java -cp out Bench` in the current environment. Times are milliseconds, average of three runs; they can vary by computer and JVM.

| test          |   size | time (ms) |
| ------------- | -----: | --------: |
| naive search  | 20,000 |      29.7 |
| naive search  | 40,000 |      72.5 |
| naive search  | 80,000 |     149.7 |
| KMP           | 20,000 |       3.0 |
| KMP           | 40,000 |       1.5 |
| KMP           | 80,000 |       0.5 |
| edit distance |    500 |       7.0 |
| edit distance |  1,000 |       9.8 |
| edit distance |  2,000 |      34.4 |
| edit distance |  4,000 |     128.3 |

The KMP measurements are very small, so JVM warm-up and measurement noise affect their individual values; theoretically, KMP grows linearly with the text plus pattern length. Edit distance grows approximately quadratically when both strings double in length, because the number of DP table cells is multiplied by about four.

## Complexity

Let `n` and `m` be the lengths of the two strains, `t` the genome length, `p` the marker length, `k` the Rabin-Karp window length, and `v` the number of people.

| algorithm                 | time                                                                             | space    | assumptions                                                                           |
| ------------------------- | -------------------------------------------------------------------------------- | -------- | ------------------------------------------------------------------------------------- |
| Edit distance             | O(nm)                                                                            | O(nm)    | Full DP table                                                                         |
| LCS                       | O(nm)                                                                            | O(nm)    | Full DP table                                                                         |
| Prefix function and KMP   | O(p + t)                                                                         | O(p + z) | `z` is the number of matches returned                                               |
| Rabin-Karp (shared words) | Expected O(n + m + k) plus verification; worst O(nmk) with heavy hash collisions | O(m)     | Hash table stores B-window positions; equal hashes are checked character-by-character |
| Tree DP                   | O(v)                                                                             | O(v)     | Tree adjacency lists and iterative traversal                                          |
